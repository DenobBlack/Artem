﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using LabWork16.View.Windows;
using Microsoft.Win32;

namespace LabWork16.Services
{
    class WindowsService
    {
        public void OpenCreateProcessWindow()
        {
            var window = new CreateProcessWindow();
            window.ShowDialog();
            window.Close();
        }

        public void OpenMessageBoxError()
        {
            MessageBox.Show("Не удалось запустить процесс", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        public string OpenFileDialogWindow()
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            if(fileDialog.ShowDialog() == true)
            {
                return fileDialog.FileName;
            }
            return "";
        }
    }
}
