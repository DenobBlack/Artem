﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using LabWork16.Services;

namespace LabWork16.ViewModels
{
    class CreateProcessViewModel : ObservableObject
    {
        private WindowsService _windowsService = new();

        private string _processPath;
        public string ProcessPath
        {
            get => _processPath;
            set => SetProperty(ref _processPath, value);
        }

        public CreateProcessViewModel()
        {
            SelectProcessCommand = new RelayCommand(SelectProcess);
        }

        public RelayCommand SelectProcessCommand { get; set; }
        private void SelectProcess()
        {
            ProcessPath = _windowsService.OpenFileDialogWindow();
        }
    }
}
