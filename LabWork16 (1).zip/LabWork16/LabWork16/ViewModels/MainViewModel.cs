﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using LabWork16.Services;

namespace LabWork16.ViewModels
{
    public class MainViewModel : ObservableObject
    {
        private WindowsService _windowsService = new();

        private ObservableCollection<Process> _processes;
        public ObservableCollection<Process> Processes
        {
            get => _processes;
            set => SetProperty(ref _processes, value);
        }

        private Process _selectedProcess;
        public Process SelectedProcess
        {
            get => _selectedProcess;
            set => SetProperty(ref _selectedProcess, value);
        }

        private ObservableCollection<Process> _apps;
        public ObservableCollection<Process> Apps
        {
            get => _apps;
            set => SetProperty(ref _apps, value);
        }

        private int _processesCount;
        public int ProcessesCount
        {
            get => _processesCount;
            set => SetProperty(ref _processesCount, value);
        }

        public MainViewModel()
        {
            UpdateCommand = new RelayCommand(Update);
            KillProcessCommand = new RelayCommand(KillProcess);
            OpenCreateProcessWindowCommand = new RelayCommand(OpenCreateProcessWindow);
        }

        public RelayCommand UpdateCommand { get; set; }
        private void Update()
        {
            var processes = Process.GetProcesses();
            Apps = [.. processes.Where(p => !string.IsNullOrEmpty(p.MainWindowTitle))];
            Processes = [.. processes];
            ProcessesCount = processes.Count();
        }

        public RelayCommand KillProcessCommand { get; set; }
        private void KillProcess()
        {
            if(SelectedProcess != null)
            {
                SelectedProcess.Kill();
                SelectedProcess.WaitForExit();
            }
            Update();
        }

        public RelayCommand OpenCreateProcessWindowCommand { get; set; }
        private void OpenCreateProcessWindow()
        {
            _windowsService.OpenCreateProcessWindow();
        }
    }
}
