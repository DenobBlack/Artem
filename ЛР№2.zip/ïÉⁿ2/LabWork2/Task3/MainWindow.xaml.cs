﻿using System.Windows;

namespace Task3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void RegButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(loginTextBox.Text) && !string.IsNullOrWhiteSpace(passwordTextBox.Text)
                && !string.IsNullOrWhiteSpace(confirmationTextBox.Text) && !string.IsNullOrWhiteSpace(emailTextBox.Text))
            {
                if (passwordTextBox.Text != confirmationTextBox.Text)
                    MessageBox.Show("Пароль и подтвержение пароля не совпадают", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                else
                    MessageBox.Show("Регистрация успешна", $"Добро пожаловать, {loginTextBox.Text}", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
                MessageBox.Show("Поля ввода не должны быть пустыми", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}