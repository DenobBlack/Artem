﻿using System.Text.RegularExpressions;

// Задание 1
Console.Write("Введите возводимое число a: ");
int a = Convert.ToInt32(Console.ReadLine());
Console.Write("Введите степень n: ");
int n = Convert.ToInt32(Console.ReadLine());
var result = "";

if (a == 0 && n < 0)
{
    result = "Деление на ноль невозможно";
}
else
{
    result = $"{a} ^ {n} = {Math.Pow(a, n).ToString()}";
}
Console.WriteLine(result);

// Задание 2
Console.WriteLine("Введите пароль: ");
string password = Console.ReadLine();
string pattern = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&_+/-])[A-Za-z\d@$!%*?&_+/-]{8,30}$";
if (Regex.IsMatch(password, pattern))
    Console.WriteLine("Пароль надёжный");
else
    Console.WriteLine("Пароль ненадёжный");